import java.io.FileReader;
import java.util.ArrayList;

import au.com.bytecode.opencsv.CSVReader;



public class CSVFileReadDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		CSVReader reader;
		ArrayList<CSVUser> usersList=new ArrayList<CSVUser>();
		try{
			reader = new CSVReader(new FileReader("./customer.csv"));
			String[] newSt;
			String name = null;
			while((newSt=reader.readNext())!=null){
				CSVUser user = new CSVUser();
				user.setName(newSt[0]);
				user.setEmail(newSt[1]);
				user.setMobile(newSt[2]);
				user.setCountry(newSt[3]);
				   usersList.add(user);
					
			}
			
			for(CSVUser usr:usersList){
				System.out.println(usr.getName());
				System.out.println(usr.getEmail());
				System.out.println(usr.getMobile());
				System.out.println(usr.getCountry());
				System.out.println("------------------");
			}
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		


	}

}
